<?php
/*
  Plugin Name: Wooshop Piraeus Bank Payment Gateway
  Plugin URI: https://www.lsaroukos.gr
  Description: Wooshop Piraeus Bank Payment Gateway allows you to accept payment through various channels such as Maestro, Mastercard, AMex cards, Diners  and Visa cards On your Woocommerce Powered Site. This plugin is also compatible with the Polylang plugin, thus it is fully functional on multilingual sites.
  Version: 1.0.0
  Author: Lefteris Saroukos
  Author URI: https://www.lsaroukos.gr
  License: GPL-3.0+
  License URI: http://www.gnu.org/licenses/gpl-3.0.txt
  Domain Path: /languages
 */
 /*
 Based on original plugin "Piraeus Bank Greece Payment Gateway for WooCommerce" by emspace.gr [https://wordpress.org/plugins/woo-payment-gateway-piraeus-bank-greece/]
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!defined('ABSPATH'))
    exit;
    
if(!class_exists('WOOSHOP_PB_Gateway') && class_exists('WC_Payment_Gateway')){   
    
  class WOOSHOP_PB_Gateway extends WC_Payment_Gateway {
  /**
  * Gateway class
  */
  
      function load_textdomain(){
        load_plugin_textdomain('wooshop-pb-gateway', false, dirname(plugin_basename(__FILE__)) . '/languages/');
      }
      
      function set_wooshop_language(){
        if(function_exists('pll_current_language'))
          $_SESSION['wooshop_language'] = pll_current_language();
      }
        
      function create_response_post_type(){
        $labels = array('name' => __('Piraeus Bank Response','wooshop-piraeus'), 'add_new_item' => __('Add New Response','wooshop-piraeus'));
        register_post_type('wc_piraeus_response',array(
            'labels'        => $labels,
            'description'   => __('stores the information from piraeus bank response'),
            'public'        =>  true,
            'menu_icon'     => 'dashicons-building',
            'supports'      => array('title','editor')
        ));
      }
  
      public function __construct() {
      global $woocommerce;
        add_action('init',array($this, 'create_response_post_type'));   //creates custom post type that stores repsonse information
          $this->id = 'piraeusbank_gateway';
          $this->icon = apply_filters('piraeusbank_icon', plugins_url('img/PB_blue_GR.png', __FILE__));
          $this->has_fields = true;
          $this->notify_url = WC()->api_request_url('WOOSHOP_PB_Gateway');
          $this->method_description = __('Piraeus bank Payment Gateway allows you to accept payment through various channels such as Maestro, Mastercard, AMex cards, Diners  and Visa cards On your Woocommerce Powered Site.', 'wooshop-pb-gateway');
          $this->redirect_page_id = $this->get_option('redirect_page_id');
          $this->method_title = 'Piraeus bank  Gateway';

          // Load the form fields.
          $this->init_form_fields();    //prepares the html code of the back-end options


          // Load the settings.
          $this->init_settings();

          // Define user set variables
          $this->title = $this->get_option('title');
          $this->description = $this->get_option('description');
          $this->pb_PayMerchantId = $this->get_option('pb_PayMerchantId');
          $this->pb_AcquirerId = $this->get_option('pb_AcquirerId');
          $this->pb_PosId = $this->get_option('pb_PosId');
          $this->pb_Username = $this->get_option('pb_Username');
          $this->pb_Password = $this->get_option('pb_Password');
          $this->pb_ProxyHost = $this->get_option('pb_ProxyHost');
          $this->pb_ProxyPort = $this->get_option('pb_ProxyPort');
          $this->pb_ProxyUsername = $this->get_option('pb_ProxyUsername');
          $this->pb_ProxyPassword = $this->get_option('pb_ProxyPassword');
          $this->pb_authorize = $this->get_option('pb_authorize');
          $this->pb_installments = $this->get_option('pb_installments');
          
          //Actions
          add_action('init',array($this,'load_textdomain'));
          add_filter('woocommerce_payment_gateways', array($this,'woocommerce_add_piraeusbank_gateway'));  //apends this to the wc gateway methods
          add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));  //hook to save changes in admin options
          add_filter('plugin_action_links', array($this,'piraeusbank_plugin_action_links'), 10, 2);   //adds settings links to the plugin activation page
          add_action('the_post', array($this,'piraeusbank_message')); //adds a wc notice, i.e. a message to be displayed on the frontend
          add_action('the_post', array($this,'load_common_checkout_scripts')); //adds javascript to the common-checkout page that will be used to redirect to piraeus bank website
          add_action('woocommerce_receipt_piraeusbank_gateway', array($this, 'receipt_page'));  //displays message after visitor has sent the payment form
          add_action('woocommerce_after_checkout_billing_form',array($this, 'set_wooshop_language'));   //initializes a special cookie that holds the language code of checkout page

            
          //Payment listener/API hook
          add_action('woocommerce_api_wc_piraeusbank_gateway', array($this, 'check_piraeusbank_response')); //handles payment response
          
          //creates wc-piraeusbank-common-checkout page if it does not exist
          if( get_page_by_title('wc-piraeusbank-common-checkout') === null ){
            wp_insert_post(array(
                'ID'          => 0,
                'post_type'   => 'page',
                'post_title'  => 'wc-piraeusbank-common-checkout',
                'post_status' => 'publish'
            ));          
          }
      }

    /**
     * appends settings link to the plugin activation page
     **/
      function piraeusbank_plugin_action_links($links, $file) {
          if (version_compare(WOOCOMMERCE_VERSION, "2.1") <= 0)           //Add Settings link to the plugin entry in the plugins menu for WC below 2.1
              $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=WOOSHOP_PB_Gateway">Settings</a>';
          else
              $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=woocommerce_settings&tab=payment_gateways&section=WC_piraeusbank_Gateway">Settings</a>';
          static $this_plugin;

          if (!$this_plugin) {
              $this_plugin = plugin_basename(__FILE__);
          }

          if ($file == $this_plugin) {
              array_unshift($links, $settings_link);
          }
          return $links;
      }
      
      /**
      * Add Piraeus Bank Gateway to WC
      * */
      function woocommerce_add_piraeusbank_gateway($methods) {
          $methods[] = 'WOOSHOP_PB_Gateway';
          return $methods;
      }

      /**
        * Admin Panel Options
        * */
      public function admin_options() {
          echo '<h3>' . __('Piraeus Bank Gateway', 'wooshop-pb-gateway') . '</h3>';
          echo '<p>' . __('Piraeus Bank Gateway allows you to accept payment through various channels such as Maestro, Mastercard, AMex cards, Diners  and Visa cards.', 'wooshop-pb-gateway') . '</p>';


          echo '<table class="form-table">';
          $this->generate_settings_html();
          echo '</table>';
      }
      
      function piraeusbank_message() {
      //prints messages from wc_cookies
        if(is_order_received_page() || (get_the_ID() == $this->redirect_page_id) && isset($_SESSION['wooshop_message_type']) ){
            if( $_SESSION['wooshop_message_type'] == 'fail'){
              $message =__('Thank you for shopping with us. <br />However, the transaction wasn\'t successful, payment wasn\'t received.', 'wooshop-pb-gateway');
              wc_add_notice(__('Payment error:', 'wooshop-pb-gateway') . $message, 'error');   //sets a message in a session to be displayed anywhere on the front-end by calling wc_print_notices()
            }elseif( $_SESSION['wooshop_message_type'] == 'error' ){
              $message = __('A technical problem occured. <br/>The transaction wasn\'t successful, payment wasn\'t received.', 'wooshop-pb-gateway');
              wc_add_notice(__('Payment error:', 'wooshop-pb-gateway') . $message, 'error');
            }elseif( $_SESSION['wooshop_message_type'] == 'process'){
              $message = __('Thank you for shopping with us.<br />Your transaction was successful, payment was received.<br />Your order is currently being processed.', 'wooshop-pb-gateway');
              wc_add_notice( $message, 'success' ); 
            }elseif( $_SESSION['wooshop_message_type'] == 'success'){
              $message = __('Thank you for shopping with us.<br />Your transaction was successful, payment was received.<br />Your order is now complete.', 'wooshop-pb-gateway');
              wc_add_notice( $message, 'success' );
            }
            wc_print_notices(); //display any message was set by add_wc_notice and displays it ini a stylish box
            unset($_SESSION['wooshop_message_type']); 
        }
      }

      /**
        * Initialise Gateway Settings Form Fields
        * */
      function init_form_fields() {
        /**
         * stores in $this->form_fields the html coed of the options to be added at the backend 
         **/
          $this->form_fields = array(
              'enabled' => array(
                  'title' => __('Enable/Disable', 'wooshop-pb-gateway'),
                  'type' => 'checkbox',
                  'label' => __('Enable Piraeus Bank Gateway', 'wooshop-pb-gateway'),
                  'description' => __('Enable or disable the gateway.', 'wooshop-pb-gateway'),
                  'desc_tip' => true,
                  'default' => 'yes'
              ),
              'title' => array(
                  'title' => __('Title', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('This controls the title which the user sees during checkout.', 'wooshop-pb-gateway'),
                  'desc_tip' => false,
                  'default' => __('Piraeus Bank Gateway', 'wooshop-pb-gateway')
              ),
              'description' => array(
                  'title' => __('Description', 'wooshop-pb-gateway'),
                  'type' => 'textarea',
                  'description' => __('This controls the description which the user sees during checkout.', 'wooshop-pb-gateway'),
                  'default' => __('Pay Via Piraeus Bank: Accepts  Mastercard, Visa cards and etc.', 'wooshop-pb-gateway')
              ),
              'pb_PayMerchantId' => array(
                  'title' => __('Piraeus Bank Merchant ID', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Enter Your Piraeus Bank Merchant ID', 'wooshop-pb-gateway'),
                  'default' => '',
                  'desc_tip' => true
              ),
              'pb_AcquirerId' => array(
                  'title' => __('Piraeus Bank Acquirer ID', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Enter Your Piraeus Bank Acquirer ID', 'wooshop-pb-gateway'),
                  'default' => '',
                  'desc_tip' => true
              ),
              'pb_PosId' => array(
                  'title' => __('Piraeus Bank POS ID', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Enter your Piraeus Bank POS ID', 'wooshop-pb-gateway'),
                  'default' => '',
                  'desc_tip' => true
              ), 'pb_Username' => array(
                  'title' => __('Piraeus Bank Username', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Enter your Piraeus Bank Username', 'wooshop-pb-gateway'),
                  'default' => '',
                  'desc_tip' => true
              ), 'pb_Password' => array(
                  'title' => __('Piraeus Bank Password', 'wooshop-pb-gateway'),
                  'type' => 'password',
                  'description' => __('Enter your Piraeus Bank Password', 'wooshop-pb-gateway'),
                  'default' => '',
                  'desc_tip' => true
              ), 
              'pb_ProxyHost' => array(
                  'title' => __('HTTP Proxy Hostname', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Used when your server is not behind a static IP. Leave blank for normal HTTP connection.', 'wooshop-pb-gateway'),
                  'desc_tip' => false,
                  'default' => __('', 'woocommerchttp://localhost/wordpress/wc-api/WC_Piraeusbank_Gateway?peiraeus=fail&StatusFlag=Failure&MerchantReference=306&HashKey=&Parameters=&ResultCode=981&TransactionId=&SupportReferenceID=203387910&ApprovalCode=&ResponseCode=&PackageNo=&AuthStatus=03&ButtonSubmit=Submit+Querye-piraeusbank-payment-gateway')
              ),
              'pb_ProxyPort' => array(
                  'title' => __('HTTP Proxy Port', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Used with Proxy Host.', 'wooshop-pb-gateway'),
                  'desc_tip' => false,
                  'default' => __('8888', 'wooshop-pb-gateway')
              ),
              'pb_ProxyUsername' => array(
                  'title' => __('HTTP Proxy Login Username', 'wooshop-pb-gateway'),
                  'type' => 'text',
                  'description' => __('Used with Proxy Host. Leave blank for anonymous connection.', 'wooshop-pb-gateway'),
                  'desc_tip' => false,
                  'default' => __('', 'wooshop-pb-gateway')
              ),
              'pb_ProxyPassword' => array(
                  'title' => __('HTTP Proxy Login Password', 'wooshop-pb-gateway'),
                  'type' => 'password',
                  'description' => __(' Used with Proxy Host. Leave blank for anonymous connection.', 'wooshop-pb-gateway'),
                  'desc_tip' => false,
                  'default' => __('', 'wooshop-pb-gateway')
              ),
              'pb_authorize' => array(
                  'title' => __('Pre-Authorize', 'wooshop-pb-gateway'),
                  'type' => 'checkbox',
                  'label' => __('Enable to capture preauthorized payments', 'wooshop-pb-gateway'),
                  'default' => 'yes',
                  'description' => __('Default payment method is Purchase, enable for Pre-Authorized payments. You will then need to accept them from Peiraeus Bank AdminTool', 'wooshop-pb-gateway')
              ),
              'redirect_page_id' => array(
                  'title' => __('Return Page', 'wooshop-pb-gateway'),
                  'type' => 'select',
                  'options' => $this->pb_get_pages('Select Page'),
                  'description' => __('URL of success page', 'wooshop-pb-gateway')
              ),
              'pb_installments' => array(
                  'title' => __('Max Installments', 'wooshop-pb-gateway'),
                  'type' => 'select',
                  'options' => $this->pb_get_installments('Select Installments'),
                  'description' => __('1 to 24 Installments,1 for one time payment. You must contact Peiraeus Bank first', 'wooshop-pb-gateway')
              )
          );
      }

      function pb_get_pages($title = false, $indent = true) {
          $wp_pages = get_pages('sort_column=menu_order');
          $page_list = array();
          if ($title)
              $page_list[] = $title;
          foreach ($wp_pages as $page) {
              $prefix = '';
              // show indented childarray($this,'deactivate') pages?
              if ($indent) {
                  $has_parent = $page->post_parent;
                  while ($has_parent) {
                      $prefix .= ' - ';
                      $next_page = get_page($has_parent);
                      $has_parent = $next_page->post_parent;
                  }
              }
              // add to page list array array
              $page_list[$page->ID] = $prefix . $page->post_title;
          }
          $page_list[-1] = __('Thank you page', 'wooshop-pb-gateway');
          return $page_list;
      }

      function pb_get_installments($title = false, $indent = true) {
          for ($i = 0; $i <= 24; $i++) {
              $installment_list[$i] = $i;
          }
          return $installment_list;
      }

      function payment_fields() {
          if ($description = $this->get_description()) {
              echo wpautop(wptexturize($description));
          }
          $installments = $this->pb_installments;
          if ($installments > 1) {
              $doseis_field = '<p class="form-row ">
    <label for="' . esc_attr($this->id) . '-card-doseis">' . __('Choose Installments', 'wooshop-pb-gateway') . ' <span class="required">*</span></label>
                      <select id="' . esc_attr($this->id) . '-card-doseis" name="' . esc_attr($this->id) . '-card-doseis" class="input-select wc-credit-card-form-card-doseis">
                      ';
              for ($i = 1; $i <= $installments; $i++) {
                  $doseis_field .= '<option value="' . $i . '">' . $i . '</option>';
              }
              $doseis_field .= '</select>			
  </p>';
              echo $doseis_field;
          }
      }

      /**
        * Generate the  Piraeus Payment button link
        * */
      public function generate_piraeusbank_form($order_id){
          global $woocommerce;
          global $wpdb;
          

          $order = new WC_Order($order_id);
          if ($this->pb_authorize == "yes") {
              $requestType = '00';
              $ExpirePreauth = '30';
          } else {
              $requestType = '02';
              $ExpirePreauth = '0';
          }
          $installments = 0;
          /* if ($this->pb_installments > 1) {
            $installments = intval($order->get_total() / 30);
            $installments = min($installments, $this->pb_installments);
            } */
          if (method_exists($order, 'get_meta')) {
              $installments = $order->get_meta('_doseis');
              if ($installments == '') {
                  $installments = 0;
              }
          } else {
              $installments = get_post_meta($order_id, '_doseis', 1);
          }
          try {
              /* ---initialize SoapClient--- */
              if( $this->pb_ProxyHost!=''){      //if proxy settings are defined
                  if($this->pb_ProxyUsername != '' && $this->pb_ProxyPassword != ''){
                      $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL",
                      array(
                          'proxy_host'     => $this->pb_ProxyHost,
                          'proxy_port'     => intval($this->pb_ProxyPort),
                          'proxy_login'    => $this->pb_ProxyUsername,
                          'proxy_password' => $this->pb_ProxyPassword
                          )
                      );
                  }
                  else{
                      $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL",
                      array(
                          'proxy_host'     => $this->pb_ProxyHost,
                          'proxy_port'     => intval($this->pb_ProxyPort)
                          )
                      );                  
                  }
              }else{  //if there are no proxy settings defined at the back-end settings page
                  $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL");
              }
              /* ---/initialize SoapClient--- */
              
              $ticketRequest = array(
                  'Username' => $this->pb_Username,
                  'Password' => hash('md5', $this->pb_Password),
                  'MerchantId' => $this->pb_PayMerchantId,
                  'PosId' => $this->pb_PosId,
                  'AcquirerId' => $this->pb_AcquirerId,
                  'MerchantReference' => $order_id,
                  'RequestType' =>  $requestType,
                  'ExpirePreauth' => $ExpirePreauth,
                  'Amount' => $order->get_total(),
                  'CurrencyCode' => '978',
                  'Installments' => (($installments==1 || $installments=='1') ? 0 : $installments),
                  'Bnpl' => '0',
                  'Parameters' => ''
              );

              $xml = array(
                  'Request' => $ticketRequest
              );

              $oResult = $soap->IssueNewTicket($xml);
              if ($oResult->IssueNewTicketResult->ResultCode == 0) {
                  //  store TranTicket in session	
                  $tt = isset($_SESSION['trans_ticket']) ? json_decode($_SESSION['trans_ticket']) : array();
                  $tt[] =  $oResult->IssueNewTicketResult->TranTicket;
                  $_SESSION['trans_ticket'] = json_encode($tt);

                  //redirect to payment
                
                  //shows the box message
                  wc_enqueue_js('
      $.blockUI({
          message: "' . esc_js(__('Thank you for your order. We are now redirecting you to Piraeus Bank to make payment.', 'wooshop-pb-gateway')) . '",
          baseZ: 99999,
          overlayCSS:
          {
            background: "#fff",
            opacity: 0.6
          },
          css: {
            padding:        "20px",
            zindex:         "9999999",
            textAlign:      "center",
            color:          "#555",
            border:         "3px solid #aaa",
            backgroundColor:"#fff",
            cursor:         "wait",
            lineHeight:		"24px",
          }
        });
    ');
    
                  /* --decide display language according to pll language code-- */ 
                  $LanCode = "en-US"; 
                  if(isset($_SESSION['wooshop_language']) ){
                    $pll_code = $_SESSION['wooshop_language'];
                    if(strstr($pll_code,'el')){
                      $LanCode = "el-GR";
                    }
                  }
                  /*
                    Other available Language codes
                    el-GR: Greek
                    en-US: English
                    ru-RU: Russian
                    de-DE: German
                    */
                  echo '<form action="' . esc_url("https://paycenter.piraeusbank.gr/redirection/pay.aspx") . '" method="post" id="pb_payment_form" target="_top">				
      
          <input type="hidden" id="AcquirerId" name="AcquirerId" value="' . esc_attr($this->pb_AcquirerId) . '"/>
          <input type="hidden" id="MerchantId" name="MerchantId" value="' . esc_attr($this->pb_PayMerchantId) . '"/>
          <input type="hidden" id="PosID" name="PosID" value="' . esc_attr($this->pb_PosId) . '"/>
          <input type="hidden" id="User" name="User" value="' . esc_attr($this->pb_Username) . '"/>
          <input type="hidden" id="LanguageCode"  name="LanguageCode" value="' . $LanCode . '"/>
          <input type="hidden" id="MerchantReference" name="MerchantReference"  value="' . esc_attr($order_id) . '"/>
        <!-- Button Fallback -->
        <div class="payment_buttons">
          <input type="submit" class="button alt" id="submit_pb_payment_form" value="' . __('Pay via Pireaus Bank', 'wooshop-pb-gateway') . '" /> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'wooshop-pb-gateway') . '</a>
          
        </div>
      </form>
      <script type="text/javascript">
        //jQuery(".payment_buttons").hide();
        </script>';
        wc_enqueue_js('jQuery("#submit_pb_payment_form").click();');
              } else {

                  echo __('An error occured, please contact the Administrator', 'wooshop-pb-gateway');
                  echo ('Result code is ' . $oResult->IssueNewTicketResult->ResultCode);
                  $order->add_order_note(__('Error' . $oResult->IssueNewTicketResult->ResultCode.':'.$oResult->IssueNewTicketResult->ResultDescription, ''));                   
              }
          } catch (SoapFault $fault) {
              $order->add_order_note(__('Error' . $fault, ''));
              echo __('Error' . $fault, '');
          }
      }

      /**
        * Process the payment and return the result
        * */
      function process_payment($order_id) {
        /* 
            This function is called when proceed to payment is pressed
            get_permalink was used instead of $order->get_checkout_payment_url in redirect in order to have a fixed checkout page to provide to Piraeus Bank
          */  
            
          $order = new WC_Order($order_id);
          $doseis = intval($_POST[esc_attr($this->id) . '-card-doseis']);
          if ($doseis > 0) {
              $this->generic_add_meta($order_id, '_doseis', $doseis);
          }

          return array(
              'result' => 'success',
              'redirect' => add_query_arg('order-pay', $order->get_id(), add_query_arg('key', $order->get_order_key(), wc_get_page_permalink('checkout')))  //forms the url http(s)://example.com/checkout_page/order_received_page/{order_id}/?key={key_name}
              //'redirect' => add_query_arg('order', $order->get_id(), add_query_arg('key', $order->get_order_key(), get_permalink(wc_get_page_id('checkout')).'order-pay/'.$order->get_id()))
          );
      }

      function receipt_page($order) {
      /**
       * after the visitor has submited the payment form, this function is called to redirect to piraeus bank page
       **/
          echo '<p>' . __('Thank you - your order is now pending payment. You should be automatically redirected to Peiraeus Paycenter to make payment.', 'wooshop-pb-gateway') . '</p>';
          //must be redirected to common php file
          $common_page = post_exists('wc-piraeusbank-common-checkout');
          $url = get_permalink($common_page);
          echo "
            <form hidden id='common-checkout-redirect' action='$url' method='POST'>
              <input name='order' value='$order'>
            </form>
            <script>
              document.getElementById('common-checkout-redirect').submit();
            </script>
          ";
      }
      
      function load_common_checkout_scripts(){
        if(get_the_title() == 'wc-piraeusbank-common-checkout'){  //run only in common-checkout page
            if( isset($_POST['order'])  ){
                //echo '<p>' . __('Thank you - your order is now pending payment. You should be automatically redirected to Peiraeus Paycenter to make payment.', 'wooshop-pb-gateway') . '</p>';
                $this->generate_piraeusbank_form($_POST['order']);
            }
        }
      }
      
      function check_piraeusbank_response() {
      /**
       * This function retrieves inforamtion from a special URL that the user is redirected to after completing a transaction to piraeus bank website
       * It then, stores the information to the database and the returned message to a cookie, redirects to a custom page from where this message should be displayed
       **/
          global $woocommerce;
          global $wpdb;
          $ResultCode = $_GET['ResultCode'];
          $ResponseCode = $_GET['ResponseCode'];
          $AuthStatus = $_GET['AuthStatus'];

          if (isset($_GET['peiraeus']) && ($_GET['peiraeus'] == 'success')) {   //if success url is returned
              $ResultCode = $_GET['ResultCode'];
              $order_id = $_GET['MerchantReference'];
              $order = new WC_Order($order_id);

              if ($ResultCode != 0) {
                  $_SESSION['wooshop_message_type'] = 'error';
                  //Update the order status
                  $order->update_status('failed', '');
                  $checkout_url = $woocommerce->cart->get_checkout_url();
                  wp_redirect($checkout_url);
                  exit;
              }

              $StatusFlag = $_GET['StatusFlag'];
              $HashKey = $_GET['HashKey'];
              $SupportReferenceID = $_GET['SupportReferenceID'];
              $ApprovalCode = $_GET['ApprovalCode'];
              $Parameters = $_GET['Parameters'];
              $PackageNo = $_GET['PackageNo'];
              
              $response = array();
              if( isset($_GET['SupportReferenceID']) )
                array_push($response, 'SupportReferenceID', $_GET['SupportReferenceID'] );
              if( isset($_GET['MerchantReference']) )
                array_push($response, 'MerchantReference', $_GET['MerchantReference'] );
              if( isset($_GET['ResultCode']) )
                array_push($response, 'ResultCode', $_GET['ResultCode'] );
              if( isset($_GET['ResponseCode']) )
                array_push($response, 'ResponseCode', $_GET['ResponseCode'] );
              if( isset($_GET['ResponseDescription']) )
                array_push($response, 'ResponseDescription', $_GET['ResponseDescription'] );
              if( isset($_GET['AuthStatus']) )
                array_push($response, 'AuthStatus', $_GET['AuthStatus'] );
              if( isset($_GET['StatusFlag']) )
                array_push($response, 'StatusFlag', $_GET['StatusFlag'] );
              if( isset($_GET['PackageNo']) )
                array_push($response, 'PackageNo', $_GET['PackageNo'] );
              if( isset($_GET['ApprovalCode']) )
                array_push($response, 'ApprovalCode', $_GET['ApprovalCode'] );
              if( isset($_GET['TransactionId']) )
                array_push($response, 'TransactionId', $_GET['TransactionId'] );
              $r = wp_insert_post(array('post_type'=>'wc_piraeus_response','post_content'=>json_encode($response), 'post_title'=>$SupportReferenceID) );

              $tt = isset($_SESSION['trans_ticket'])? json_decode($_SESSION['trans_ticket']) : array();
              unset($_SESSION['trans_ticket']);
              
              $hasHashKeyNotMatched = true;

                  foreach($tt as $transaction) {
                      
                      if(!$hasHashKeyNotMatched)
                          break;

                      $transticket = $transaction;

                      $stcon = $transticket . $this->pb_PosId . $this->pb_AcquirerId . $order_id . $ApprovalCode . $Parameters . $ResponseCode . $SupportReferenceID . $AuthStatus . $PackageNo . $StatusFlag;

                      $conhash = strtoupper(hash('sha256', $stcon));

                      // $newHashKey
                      $stconHmac = $transticket . ';' . $this->pb_PosId . ';' .  $this->pb_AcquirerId . ';' .  $order_id . ';' .  $ApprovalCode . ';' .  $Parameters . ';' .  $ResponseCode . ';' .  $SupportReferenceID . ';' .  $AuthStatus . ';' .  $PackageNo . ';' .  $StatusFlag;
                      $consHashHmac = strtoupper(hash_hmac('sha256', $stconHmac, $transticket, false));

                          if($consHashHmac != $HashKey && $conhash != $HashKey) {
                              continue;
                          } else {
                              $hasHashKeyNotMatched= false;
                          }
                  }

              if($hasHashKeyNotMatched) {
                  
                /* if the information received from the bank are not valid */ 
//                  $message = __('Thank you for shopping with us. <br />However, the transaction wasn\'t successful, payment wasn\'t received.', 'wooshop-pb-gateway');
                  $_SESSION['wooshop_message_type'] = 'error';
                  //Update the order status
                  $order->update_status('failed', '');
                  $checkout_url = $woocommerce->cart->get_checkout_url();
                  wp_redirect($checkout_url);
                  exit;
              }else{
                  /* if hashes match */
                  if ($ResponseCode == 0 || $ResponseCode == 8 || $ResponseCode == 10 || $ResponseCode == 16) {

                      if ($order->get_status() == 'processing') {

                          $order->add_order_note(__('Payment Via Peiraeus Bank<br />Transaction ID: ', 'wooshop-pb-gateway') . $SupportReferenceID);

                          //Add customer order note
                          $order->add_order_note(__('Payment Received.<br />Your order is currently being processed.<br />We will be shipping your order to you soon.<br />Peiraeus Bank ID: ', 'wooshop-pb-gateway') . $SupportReferenceID, 1);

                          // Reduce stock levels
                          $order->reduce_order_stock();
                          // Empty cart
                          WC()->cart->empty_cart();

                          $_SESSION['wooshop_message_type'] = 'process';
                      }else{

                          if ($order->has_downloadable_item()) {

                              //Update order status
                              $order->update_status('completed', __('Payment received, your order is now complete.', 'wooshop-pb-gateway'));

                              //Add admin order note
                              $order->add_order_note(__('Payment Via Peiraeus Bank<br />Transaction ID: ', 'wooshop-pb-gateway') . $SupportReferenceID);

                              //Add customer order note
                              $order->add_order_note(__('Payment Received.<br />Your order is now complete.<br />Peiraeus Transaction ID: ', 'wooshop-pb-gateway') . $SupportReferenceID, 1);

                              $_SESSION['wooshop_message_type'] = 'success';
                          } else {
                              //Update order status
                              $order->update_status('processing', __('Payment received, your order is currently being processed.', 'wooshop-pb-gateway'));

                              //Add admin order note
                              $order->add_order_note(__('Payment Via Peiraeus Bank<br />Transaction ID: ', 'wooshop-pb-gateway') . $SupportReferenceID);

                              //Add customer order note
                              $order->add_order_note(__('Payment Received.<br />Your order is currently being processed.<br />We will be shipping your order to you soon.<br />Peiraeus Bank ID: ', 'wooshop-pb-gateway') . $SupportReferenceID, 1);

                              $_SESSION['wooshop_message_type'] = 'success';
                          }

                          // Reduce stock levels
                          $order->reduce_order_stock();
                      }

                      // Empty cart if a successfull transaction was completed
                      if( isset($_GET['peiraeus']) && ($_GET['peiraeus'] == 'success') )
                        WC()->cart->empty_cart();
                  } else { //Failed Response codes

                        $_SESSION['wooshop_message_type'] = 'fail';
                        
                        //Update the order status
                        $order->update_status('failed', '');
                  }
              }
          }
          if (isset($_GET['peiraeus']) && ($_GET['peiraeus'] == 'fail')) {
            $_SESSION['wooshop_message_type'] = 'fail';
            $SupportReferenceID = $_GET['SupportReferenceID'];
            $response = array();    
              if( isset($_GET['SupportReferenceID']) )
                array_push($response, 'SupportReferenceID', $_GET['SupportReferenceID'] );
              if( isset($_GET['MerchantReference']) )
                array_push($response, 'MerchantReference', $_GET['MerchantReference'] );
              if( isset($_GET['ResultCode']) )
                array_push($response, 'ResultCode', $_GET['ResultCode'] );
              if( isset($_GET['ResponseCode']) )
                array_push($response, 'ResponseCode', $_GET['ResponseCode'] );
              if( isset($_GET['ResponseDescription']) )
                array_push($response, 'ResponseDescription', $_GET['ResponseDescription'] );
              if( isset($_GET['AuthStatus']) )
                array_push($response, 'AuthStatus', $_GET['AuthStatus'] );
              if( isset($_GET['StatusFlag']) )
                array_push($response, 'StatusFlag', $_GET['StatusFlag'] );
              if( isset($_GET['PackageNo']) )
                array_push($response, 'PackageNo', $_GET['PackageNo'] );
              if( isset($_GET['ApprovalCode']) )
                array_push($response, 'ApprovalCode', $_GET['ApprovalCode'] );
              if( isset($_GET['TransactionId']) )
                array_push($response, 'TransactionId', $_GET['TransactionId'] );
              $r = wp_insert_post(array('post_type'=>'wc_piraeus_response','post_content'=>json_encode($response), 'post_title'=>$SupportReferenceID) );

              if (isset($_GET['MerchantReference'])) {
                  $order_id = $_GET['MerchantReference'];
                  $order = new WC_Order($order_id);
                  $transaction_id = $_GET['SupportReferenceID'];
                  //Add Customer Order Note
                  $order->add_order_note($message . '<br />Piraeus Bank Transaction ID: ' . $transaction_id, 1);
                  //Add Admin Order Note
                  $order->add_order_note($message . '<br />Piraeus Bank Transaction ID: ' . $transaction_id);
                  //Update the order status
                  $order->update_status('failed', '');
              }
          }
          if (isset($_GET['peiraeus']) && ($_GET['peiraeus'] == 'cancel')) {
              $SupportReferenceID = $_GET['SupportReferenceID'];
              $response = array();    
              if( isset($_GET['SupportReferenceID']) )
                array_push($response, 'SupportReferenceID', $_GET['SupportReferenceID'] );
              if( isset($_GET['MerchantReference']) )
                array_push($response, 'MerchantReference', $_GET['MerchantReference'] );
              if( isset($_GET['ResultCode']) )
                array_push($response, 'ResultCode', $_GET['ResultCode'] );
              if( isset($_GET['ResponseCode']) )
                array_push($response, 'ResponseCode', $_GET['ResponseCode'] );
              if( isset($_GET['ResponseDescription']) )
                array_push($response, 'ResponseDescription', $_GET['ResponseDescription'] );
              if( isset($_GET['AuthStatus']) )
                array_push($response, 'AuthStatus', $_GET['AuthStatus'] );
              if( isset($_GET['StatusFlag']) )
                array_push($response, 'StatusFlag', $_GET['StatusFlag'] );
              if( isset($_GET['PackageNo']) )
                array_push($response, 'PackageNo', $_GET['PackageNo'] );
              if( isset($_GET['ApprovalCode']) )
                array_push($response, 'ApprovalCode', $_GET['ApprovalCode'] );
              if( isset($_GET['TransactionId']) )
                array_push($response, 'TransactionId', $_GET['TransactionId'] );
              $r = wp_insert_post(array('post_type'=>'wc_piraeus_response','post_content'=>json_encode($response), 'post_title'=>$SupportReferenceID) );

              $checkout_url = $woocommerce->cart->get_checkout_url();
              wp_redirect($checkout_url);
              exit;
          }

          //--get the redirect page url--
          if ($this->redirect_page_id == "-1" || $this->redirect_page_id == 0) {
              $redirect_url = $this->get_return_url($order);    //woocommerce function that returns the order-received page
            if(function_exists('pll_get_post_language')){ //if pollylang is activated
                $redirect_id = url_to_postid( $redirect_url );
                if( pll_get_post_language($redirect_id)!= $_SESSION['wooshop_language'] ){     //if the order-received page is not displayed in the selected language
                    $translation_id = pll_get_post($redirect_id, $_SESSION['wooshop_language']);
                    $translation_permalink = get_permalink($translation_id);
                    $redirect_permalink = get_permalink($redirect_id);
                    $redirect_url = str_replace($redirect_permalink,$translation_permalink,$redirect_url);
                }
            }
          } else {
              $redirect_url = ($this->redirect_page_id == "" || $this->redirect_page_id == 0) ? get_site_url() . "/" : get_permalink($this->redirect_page_id);
              //For wooCoomerce 2.0
              $redirect_url = add_query_arg(array('msg' => urlencode($this->msg['message']), 'type' => $this->msg['class']), $redirect_url);
          }

          wp_redirect($redirect_url);   //redirects to "Return Page", defined at the payment options
          exit;
    }

      function generic_add_meta($orderid, $key, $value) {
          $order = new WC_Order($orderid);
          if (method_exists($order, 'add_meta_data') && method_exists($order, 'save_meta_data')) {
              $order->add_meta_data($key, $value, true);
              $order->save_meta_data();
          } else {
              update_post_meta($orderid, $key, $value);
          }
      }

    
  }
  
}   //--end of class definition
    
if(class_exists('WOOSHOP_PB_Gateway')){   

  $pb_gateway = new WOOSHOP_PB_Gateway();
}

?>