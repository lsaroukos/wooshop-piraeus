<?php 

if (!defined('ABSPATH'))
    die("bye");
  function test($order_id) {
    $payment_gateway_id = 'piraeusbank_gateway';    
//     $payment_gateways   = WC_Payment_Gateways::instance();
    $test = get_option('woocommerce_piraeusbank_gateway_settings');
    echo $test;
    
    print_r($payment_gateways);
           
//           $temp->title = $wc->get_option('title');
//           $temp->description = $wc->get_option('description');
//           $temp->pb_PayMerchantId = $wc->get_option('pb_PayMerchantId');
//           $temp->pb_AcquirerId = $wc->get_option('pb_AcquirerId');
//           $temp->pb_PosId = $wc->get_option('pb_PosId');
//           $temp->pb_Username = $wc->get_option('pb_Username');
//           $temp->pb_Password = $wc->get_option('pb_Password');
//           $temp->pb_ProxyHost = $wc->get_option('pb_ProxyHost');
//           $temp->pb_ProxyPort = $wc->get_option('pb_ProxyPort');
//           $temp->pb_ProxyUsername = $wc->get_option('pb_ProxyUsername');
//           $temp->pb_ProxyPassword = $wc->get_option('pb_ProxyPassword');
//           $temp->pb_authorize = $wc->get_option('pb_authorize');
//           $temp->pb_installments = $wc->get_option('pb_installments');
          global $woocommerce;
          global $wpdb;

          $order = new WC_Order($order_id);
          //echo $temp->pb_authorize;

          if ($temp->pb_authorize == "yes") {
              $requestType = '00';
              $ExpirePreauth = '30';
          } else {
              $requestType = '02';
              $ExpirePreauth = '0';
          }
          $installments = 1;
          /* if ($temp->pb_installments > 1) {
            $installments = intval($order->get_total() / 30);
            $installments = min($installments, $temp->pb_installments);
            } */
          if (method_exists($order, 'get_meta')) {
              $installments = $order->get_meta('_doseis');
              if ($installments == '') {
                  $installments = 1;
              }
          } else {
              $installments = get_post_meta($order_id, '_doseis', 1);
          }
          try {
              
              if( $temp->pb_ProxyHost!=''){
                  
                  if($temp->pb_ProxyUsername != '' && $temp->pb_ProxyPassword != ''){
                      $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL",
                      array(
                          'proxy_host'     => $temp->pb_ProxyHost,
                          'proxy_port'     => intval($temp->pb_ProxyPort),
                          'proxy_login'    => $temp->pb_ProxyUsername,
                          'proxy_password' => $temp->pb_ProxyPassword
                          )
                      );
                  }
                  else{
                      $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL",
                      array(
                          'proxy_host'     => $temp->pb_ProxyHost,
                          'proxy_port'     => intval($temp->pb_ProxyPort)
                          )
                      );                  
                  }
              }
              else{
                  $soap = new SoapClient("https://paycenter.piraeusbank.gr/services/tickets/issuer.asmx?WSDL");
              }
              $ticketRequest = array(
                  'Username' => $temp->pb_Username,
                  'Password' => hash('md5', $temp->pb_Password),
                  'MerchantId' => $temp->pb_PayMerchantId,
                  'PosId' => $temp->pb_PosId,
                  'AcquirerId' => $temp->pb_AcquirerId,
                  'MerchantReference' => $order_id,
                  'RequestType' => $requestType,
                  'ExpirePreauth' => $ExpirePreauth,
                  'Amount' => $order->get_total(),
                  'CurrencyCode' => '978',
                  'Installments' => $installments,
                  'Bnpl' => '0',
                  'Parameters' => ''
              );
              $xml = array(
                  'Request' => $ticketRequest
              );

              $oResult = $soap->IssueNewTicket($xml);
              if ($oResult->IssueNewTicketResult->ResultCode == 0) {

                  //  store TranTicket in table	
                  // $wpdb->delete($wpdb->prefix . 'piraeusbank_transactions', array('merch_ref' => $order_id));
                  $wpdb->insert($wpdb->prefix . 'piraeusbank_transactions', array('trans_ticket' => $oResult->IssueNewTicketResult->TranTicket, 'merch_ref' => $order_id, 'timestamp' => current_time('mysql', 1)));

                  //redirect to payment

                  wc_enqueue_js('
      $.blockUI({
          message: "' . esc_js(__('Thank you for your order. We are now redirecting you to Piraeus Bank to make payment.', 'woocommerce-piraeusbank-payment-gateway')) . '",
          baseZ: 99999,
          overlayCSS:
          {
            background: "#fff",
            opacity: 0.6
          },
          css: {
            padding:        "20px",
            zindex:         "9999999",
            textAlign:      "center",
            color:          "#555",
            border:         "3px solid #aaa",
            backgroundColor:"#fff",
            cursor:         "wait",
            lineHeight:		"24px",
          }
        });
      jQuery("#submit_pb_payment_form").click();
    ');

                  $LanCode = "en-US"; //lsprog
                  if(function_exists('pll_current_language') ){
                    $pll_code = pll_current_language();
                    if(strstr($pll_code,'el'))
                      $LanCode = "el-GR";
                  }
                  /*
                    Other available Language codes
                    el-GR: Greek
                    en-US: English
                    ru-RU: Russian
                    de-DE: German
                    */

                  return '<form action="' . esc_url("https://paycenter.piraeusbank.gr/redirection/pay.aspx") . '" method="post" id="pb_payment_form" target="_top">				
      
          <input type="hidden" id="AcquirerId" name="AcquirerId" value="' . esc_attr($temp->pb_AcquirerId) . '"/>
          <input type="hidden" id="MerchantId" name="MerchantId" value="' . esc_attr($temp->pb_PayMerchantId) . '"/>
          <input type="hidden" id="PosID" name="PosID" value="' . esc_attr($temp->pb_PosId) . '"/>
          <input type="hidden" id="User" name="User" value="' . esc_attr($temp->pb_Username) . '"/>
          <input type="hidden" id="LanguageCode"  name="LanguageCode" value="' . $LanCode . '"/>
          <input type="hidden" id="MerchantReference" name="MerchantReference"  value="' . esc_attr($order_id) . '"/>
        <!-- Button Fallback -->
        <div class="payment_buttons">
          <input type="submit" class="button alt" id="submit_pb_payment_form" value="' . __('Pay via Pireaus Bank', 'woocommerce-piraeusbank-payment-gateway') . '" /> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'woocommerce-piraeusbank-payment-gateway') . '</a>
          
        </div>
        <script type="text/javascript">
        jQuery(".payment_buttons").hide();
        </script>
      </form>';
              } else {
                  echo __('An error occured, please contact the Administrator', 'woocommerce-piraeusbank-payment-gateway');
                  echo ('Result code is ' . $oResult->IssueNewTicketResult->ResultCode);
                  $order->add_order_note(__('Error' . $oResult->IssueNewTicketResult->ResultCode.':'.$oResult->IssueNewTicketResult->ResultDescription, ''));                   
              }
          } catch (SoapFault $fault) {
              $order->add_order_note(__('Error' . $fault, ''));
              echo __('Error' . $fault, '');
          }
      }
    test();
?>
